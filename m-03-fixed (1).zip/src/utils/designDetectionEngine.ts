/**
 * Design Auto-Detection Engine
 * -----------------------------
 * Extracts jewelry design / model codes from free text when no explicit
 * Design column exists. Supports Diamond World style codes:
 *   NP7SD1, NP7SD21, NP7D10, KR106729SB, KR106738SB, etc.
 */

export type DesignDetectionMethod =
  | 'explicit_column'   // Design / Model / SKU header present
  | 'token_pattern'     // Standalone token matches model-code regex
  | 'embedded_pattern'  // Code embedded in description/particular text
  | 'learned_alias'     // Previously seen design from identity store
  | 'none';

export interface DesignDetectionResult {
  code: string | null;
  method: DesignDetectionMethod;
  confidence: number; // 0–1
  rawMatch?: string;
}

/** Strict model-code shape: letters + digits, optional trailing letters/digits */
const MODEL_CODE_STRICT =
  /\b([A-Za-z]{1,6}\d{1,8}[A-Za-z]{0,4}\d{0,4})\b/g;

/** Stronger signal: starts with 2+ letters then digit (NP7…, KR106…) */
const MODEL_CODE_STRONG =
  /\b([A-Za-z]{2,6}\d{1,8}[A-Za-z0-9]{0,6})\b/g;

/** Pure numeric carat-like values to exclude */
const LOOKS_LIKE_CARAT = /^(0?\.\d+|\d{1,2}(\.\d+)?)$/;

/** Common non-design words that can look code-like */
const STOP_TOKENS = new Set(
  [
    'ct', 'cts', 'pcs', 'pc', 'qty', 'stock', 'sold', 'sale', 'total', 'sum',
    'branch', 'gul', 'dwl', 'onl', 'mir', 'utt', 'ctg', 'syl', 'raj', 'khu',
    'stone', 'stones', 'diamond', 'gold', 'silver', 'ring', 'earring', 'nosepin',
    'pendant', 'bracelet', 'chain', 'set', 'pair', 'gram', 'gm', 'mm', 'size',
    'category', 'weight', 'design', 'model', 'sku', 'code', 'item', 'product',
  ].map((s) => s.toLowerCase())
);

function normalizeCode(raw: string): string {
  return String(raw || '')
    .trim()
    .toUpperCase()
    .replace(/\s+/g, '')
    .replace(/[-_/\\]+/g, '');
}

function isPlausibleDesignCode(token: string): boolean {
  if (!token || token.length < 3 || token.length > 20) return false;
  if (LOOKS_LIKE_CARAT.test(token)) return false;
  if (STOP_TOKENS.has(token.toLowerCase())) return false;
  // Must mix letters and digits (pure letters/digits alone are weak)
  const hasLetter = /[A-Za-z]/.test(token);
  const hasDigit = /\d/.test(token);
  if (!hasLetter || !hasDigit) return false;
  // Prefer codes that start with letters (NP…, KR…)
  if (!/^[A-Za-z]/.test(token)) return false;
  return true;
}

/**
 * Method A — Explicit column value (already mapped by parser).
 */
export function detectFromExplicitColumn(value: string | undefined | null): DesignDetectionResult {
  const raw = String(value || '').trim();
  if (!raw) return { code: null, method: 'none', confidence: 0 };
  const code = normalizeCode(raw);
  if (!isPlausibleDesignCode(code) && code.length < 2) {
    return { code: null, method: 'none', confidence: 0 };
  }
  // Explicit column is trusted even if pattern is unusual
  return {
    code: code || null,
    method: 'explicit_column',
    confidence: code ? 0.98 : 0,
    rawMatch: raw,
  };
}

/**
 * Method B — Standalone token pattern (cell is only the design code).
 */
export function detectFromToken(value: string | undefined | null): DesignDetectionResult {
  const raw = String(value || '').trim();
  if (!raw || /\s/.test(raw)) return { code: null, method: 'none', confidence: 0 };
  const code = normalizeCode(raw);
  if (!isPlausibleDesignCode(code)) return { code: null, method: 'none', confidence: 0 };
  const strong = /^[A-Za-z]{2,6}\d/.test(code);
  return {
    code,
    method: 'token_pattern',
    confidence: strong ? 0.9 : 0.7,
    rawMatch: raw,
  };
}

/**
 * Method C — Embedded pattern inside description / particular text.
 * e.g. "Diamond Nosepin 7 Stone NP7SD1 0.02ct" → NP7SD1
 */
export function detectFromEmbeddedText(text: string | undefined | null): DesignDetectionResult {
  const raw = String(text || '').trim();
  if (!raw || raw.length < 4) return { code: null, method: 'none', confidence: 0 };

  const candidates: { code: string; strong: boolean }[] = [];
  let m: RegExpExecArray | null;

  const strongRe = new RegExp(MODEL_CODE_STRONG.source, 'g');
  while ((m = strongRe.exec(raw)) !== null) {
    const code = normalizeCode(m[1]);
    if (isPlausibleDesignCode(code)) candidates.push({ code, strong: true });
  }

  if (candidates.length === 0) {
    const looseRe = new RegExp(MODEL_CODE_STRICT.source, 'g');
    while ((m = looseRe.exec(raw)) !== null) {
      const code = normalizeCode(m[1]);
      if (isPlausibleDesignCode(code)) candidates.push({ code, strong: false });
    }
  }

  if (candidates.length === 0) return { code: null, method: 'none', confidence: 0 };

  // Prefer longest strong match (more specific model codes)
  candidates.sort((a, b) => {
    if (a.strong !== b.strong) return a.strong ? -1 : 1;
    return b.code.length - a.code.length;
  });

  const best = candidates[0];
  return {
    code: best.code,
    method: 'embedded_pattern',
    confidence: best.strong ? 0.85 : 0.6,
    rawMatch: best.code,
  };
}

/**
 * Method D — Learned alias lookup from previous uploads (caller supplies known codes).
 */
export function detectFromLearnedAliases(
  text: string | undefined | null,
  knownCodes: string[]
): DesignDetectionResult {
  const raw = String(text || '').trim().toUpperCase().replace(/\s+/g, '');
  if (!raw || !knownCodes.length) return { code: null, method: 'none', confidence: 0 };

  const normalizedKnown = knownCodes.map((c) => normalizeCode(c)).filter(Boolean);
  // Exact
  for (const k of normalizedKnown) {
    if (raw === k) {
      return { code: k, method: 'learned_alias', confidence: 0.95, rawMatch: k };
    }
  }
  // Contained in text
  for (const k of normalizedKnown) {
    if (k.length >= 4 && raw.includes(k)) {
      return { code: k, method: 'learned_alias', confidence: 0.8, rawMatch: k };
    }
  }
  return { code: null, method: 'none', confidence: 0 };
}

/**
 * Cascade: try methods in priority order and return best result.
 */
export function autoDetectDesign(input: {
  explicitDesign?: string | null;
  weightOrParticular?: string | null;
  category?: string | null;
  itemName?: string | null;
  knownDesignCodes?: string[];
}): DesignDetectionResult {
  // 1. Explicit Design column
  const explicit = detectFromExplicitColumn(input.explicitDesign);
  if (explicit.code && explicit.confidence >= 0.9) return explicit;

  // 2. Learned aliases on combined text
  const combined = [input.explicitDesign, input.weightOrParticular, input.itemName, input.category]
    .filter(Boolean)
    .join(' ');
  if (input.knownDesignCodes?.length) {
    const learned = detectFromLearnedAliases(combined, input.knownDesignCodes);
    if (learned.code) return learned;
  }

  // 3. Token pattern on weight cell (sometimes people put model in weight column)
  const token = detectFromToken(input.weightOrParticular);
  if (token.code && token.confidence >= 0.85) return token;

  // 4. Embedded in description fields
  const embedded =
    detectFromEmbeddedText(input.itemName) ||
    detectFromEmbeddedText(input.category) ||
    detectFromEmbeddedText(input.weightOrParticular);

  // detectFromEmbeddedText always returns an object; pick highest confidence among texts
  const embeddedResults = [
    detectFromEmbeddedText(input.itemName),
    detectFromEmbeddedText(input.category),
    detectFromEmbeddedText(input.weightOrParticular),
  ].filter((r) => r.code);

  if (embeddedResults.length > 0) {
    embeddedResults.sort((a, b) => b.confidence - a.confidence);
    return embeddedResults[0];
  }

  if (explicit.code) return explicit;
  if (token.code) return token;

  return { code: null, method: 'none', confidence: 0 };
}

/**
 * Split a free-text particular that may contain both carat and design.
 * e.g. "0.02 NP7SD1" → { weight: "0.02", design: "NP7SD1" }
 */
export function splitWeightAndDesign(raw: string): { weight: string | null; design: string | null } {
  const text = String(raw || '').trim();
  if (!text) return { weight: null, design: null };

  const designHit = detectFromEmbeddedText(text);
  const design = designHit.code;

  // Carat patterns
  const caratMatch =
    text.match(/\b(0?\.\d{1,3})\b/) ||
    text.match(/\b(\d{1,2}\.\d{1,3})\b/) ||
    text.match(/\b(\d{1,2})\s*(?:ct|cts|carat)?\b/i);

  let weight: string | null = caratMatch ? caratMatch[1] : null;
  if (weight) {
    const n = parseFloat(weight);
    if (!isNaN(n)) weight = n.toFixed(2).replace(/\.?0+$/, (m) => (m.includes('.') ? m.replace(/0+$/, '').replace(/\.$/, '') === '' ? n.toFixed(2) : m : '')) || weight;
    // simpler normalize:
    weight = String(parseFloat(weight));
    if (!weight.includes('.')) {
      // keep integer carats as-is; jewelry often uses 0.xx
    }
    const num = parseFloat(caratMatch![1]);
    weight = isNaN(num) ? caratMatch![1] : (Math.round(num * 100) / 100).toFixed(2).replace(/0+$/, '').replace(/\.$/, '') || String(num);
    // Prefer standard 2-decimal when original had decimal
    if (caratMatch![1].includes('.')) {
      weight = (Math.round(num * 100) / 100).toFixed(2);
    }
  }

  // If the whole cell is only a design code, don't treat as weight
  if (!weight && design && normalizeCode(text) === design) {
    return { weight: null, design };
  }

  return { weight, design };
}
