import React, { useState } from 'react';
import {
  Sparkles,
  Plus,
  Trash2,
  Loader2,
  Check,
  AlertCircle,
  Wand2,
} from 'lucide-react';
import { RawInventoryRecord } from '../types';

export interface DesignBreakdownRow {
  design: string;
  stock: number;
  sold: number;
  confidence?: number;
}

interface AIDesignBreakdownPanelProps {
  onApplyRecords: (records: RawInventoryRecord[]) => void;
}

export const AIDesignBreakdownPanel: React.FC<AIDesignBreakdownPanelProps> = ({
  onApplyRecords,
}) => {
  const [branch, setBranch] = useState('GUL');
  const [category, setCategory] = useState('Diamond Nosepin 7 Stone');
  const [weight, setWeight] = useState('0.02');
  const [totalStock, setTotalStock] = useState('20');
  const [totalSold, setTotalSold] = useState('3');
  const [notes, setNotes] = useState(
    'NP7SD1 10pcs, NP7SD21 5pcs, NP7D10 5pcs'
  );
  const [rows, setRows] = useState<DesignBreakdownRow[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [isSimulated, setIsSimulated] = useState(false);
  const [applied, setApplied] = useState(false);

  const stockSum = rows.reduce((s, r) => s + (Number(r.stock) || 0), 0);
  const soldSum = rows.reduce((s, r) => s + (Number(r.sold) || 0), 0);
  const targetStock = parseInt(totalStock, 10) || 0;
  const targetSold = parseInt(totalSold, 10) || 0;
  const stockOk = rows.length === 0 || stockSum === targetStock;
  const soldOk = rows.length === 0 || soldSum === targetSold;

  const handleGenerate = async () => {
    setError('');
    setApplied(false);
    setIsLoading(true);
    try {
      const res = await fetch('/api/gemini/design-breakdown', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          branch,
          category,
          weight,
          totalStock: targetStock,
          totalSold: targetSold,
          notes,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'AI request failed');
      }
      if (!data.rows || data.rows.length === 0) {
        setError(
          data.message ||
            'No design rows returned. Add design codes in notes (e.g. NP7SD1 10pcs).'
        );
        setRows([]);
        return;
      }
      setRows(
        data.rows.map((r: DesignBreakdownRow) => ({
          design: r.design,
          stock: r.stock,
          sold: r.sold,
          confidence: r.confidence,
        }))
      );
      setIsSimulated(Boolean(data.isSimulated));
    } catch (e: any) {
      setError(e.message || 'Failed to generate breakdown');
    } finally {
      setIsLoading(false);
    }
  };

  const updateRow = (idx: number, patch: Partial<DesignBreakdownRow>) => {
    setRows((prev) =>
      prev.map((r, i) => (i === idx ? { ...r, ...patch } : r))
    );
    setApplied(false);
  };

  const addRow = () => {
    setRows((prev) => [...prev, { design: '', stock: 0, sold: 0, confidence: 1 }]);
    setApplied(false);
  };

  const removeRow = (idx: number) => {
    setRows((prev) => prev.filter((_, i) => i !== idx));
    setApplied(false);
  };

  const handleApply = () => {
    const valid = rows.filter((r) => r.design.trim());
    if (valid.length === 0) {
      setError('Add at least one design code.');
      return;
    }
    const records: RawInventoryRecord[] = valid.map((r, i) => {
      const code = r.design.trim().toUpperCase().replace(/\s+/g, '');
      return {
        id: `ai-design-${Date.now()}-${i}`,
        branch: branch.trim() || 'GUL',
        weight: weight.trim() || '0.02',
        itemCode: code,
        itemName: code,
        category: category.trim() || undefined,
        variant: code,
        soldQty: Number(r.sold) || 0,
        currentStock: Number(r.stock) || 0,
      };
    });
    onApplyRecords(records);
    setApplied(true);
    setError('');
  };

  return (
    <div className="border border-violet-700/40 bg-violet-950/25 rounded-xl p-4 space-y-3">
      <div className="flex items-center gap-2">
        <div className="w-8 h-8 rounded-lg bg-violet-500/20 text-violet-300 flex items-center justify-center">
          <Wand2 className="w-4 h-4" />
        </div>
        <div>
          <h3 className="text-sm font-semibold text-violet-100 flex items-center gap-1.5">
            AI Design Breakdown
            <span className="text-[10px] font-normal px-1.5 py-0.5 rounded bg-violet-500/20 text-violet-300 border border-violet-500/30">
              Same carat → many designs
            </span>
          </h3>
          <p className="text-[11px] text-violet-200/60">
            Total pcs দিন + notes-এ design codes লিখুন → AI split করে দেবে → edit করে Apply করুন
          </p>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
        <label className="text-[11px] text-violet-200/70 space-y-1">
          <span>Branch</span>
          <input
            value={branch}
            onChange={(e) => setBranch(e.target.value)}
            className="w-full rounded-lg border border-violet-700/40 bg-black/30 px-2.5 py-1.5 text-sm text-white outline-none focus:border-violet-400"
          />
        </label>
        <label className="text-[11px] text-violet-200/70 space-y-1 sm:col-span-2">
          <span>Category</span>
          <input
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="w-full rounded-lg border border-violet-700/40 bg-black/30 px-2.5 py-1.5 text-sm text-white outline-none focus:border-violet-400"
          />
        </label>
        <label className="text-[11px] text-violet-200/70 space-y-1">
          <span>Carat weight</span>
          <input
            value={weight}
            onChange={(e) => setWeight(e.target.value)}
            className="w-full rounded-lg border border-violet-700/40 bg-black/30 px-2.5 py-1.5 text-sm text-white outline-none focus:border-violet-400"
          />
        </label>
        <label className="text-[11px] text-violet-200/70 space-y-1">
          <span>Total stock (pcs)</span>
          <input
            type="number"
            min={0}
            value={totalStock}
            onChange={(e) => setTotalStock(e.target.value)}
            className="w-full rounded-lg border border-violet-700/40 bg-black/30 px-2.5 py-1.5 text-sm text-white outline-none focus:border-violet-400"
          />
        </label>
        <label className="text-[11px] text-violet-200/70 space-y-1">
          <span>Total sold (pcs)</span>
          <input
            type="number"
            min={0}
            value={totalSold}
            onChange={(e) => setTotalSold(e.target.value)}
            className="w-full rounded-lg border border-violet-700/40 bg-black/30 px-2.5 py-1.5 text-sm text-white outline-none focus:border-violet-400"
          />
        </label>
      </div>

      <label className="block text-[11px] text-violet-200/70 space-y-1">
        <span>Notes (design codes + optional counts)</span>
        <textarea
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          rows={2}
          placeholder="e.g. NP7SD1 10pcs, NP7SD21 5pcs, NP7D10 5pcs"
          className="w-full rounded-lg border border-violet-700/40 bg-black/30 px-2.5 py-1.5 text-sm text-white outline-none focus:border-violet-400 resize-y min-h-[56px]"
        />
      </label>

      <div className="flex flex-wrap items-center gap-2">
        <button
          type="button"
          onClick={handleGenerate}
          disabled={isLoading}
          className="inline-flex items-center gap-1.5 rounded-lg bg-violet-600 hover:bg-violet-500 disabled:opacity-50 px-3 py-1.5 text-xs font-semibold text-white transition"
        >
          {isLoading ? (
            <Loader2 className="w-3.5 h-3.5 animate-spin" />
          ) : (
            <Sparkles className="w-3.5 h-3.5" />
          )}
          {isLoading ? 'Generating…' : 'AI Generate Breakdown'}
        </button>
        <button
          type="button"
          onClick={addRow}
          className="inline-flex items-center gap-1 rounded-lg border border-violet-600/50 px-2.5 py-1.5 text-xs text-violet-200 hover:bg-violet-900/40 transition"
        >
          <Plus className="w-3.5 h-3.5" /> Manual row
        </button>
        {isSimulated && rows.length > 0 && (
          <span className="text-[10px] text-amber-300/80">Heuristic mode (no Gemini key)</span>
        )}
      </div>

      {error && (
        <div className="flex items-start gap-2 text-xs text-rose-300 bg-rose-950/40 border border-rose-800/40 rounded-lg p-2">
          <AlertCircle className="w-3.5 h-3.5 mt-0.5 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {rows.length > 0 && (
        <div className="rounded-lg border border-violet-800/40 overflow-hidden">
          <table className="w-full text-xs">
            <thead>
              <tr className="bg-violet-950/60 text-violet-300/90">
                <th className="text-left px-2 py-1.5 font-medium">Design</th>
                <th className="text-right px-2 py-1.5 font-medium w-20">Stock</th>
                <th className="text-right px-2 py-1.5 font-medium w-20">Sold</th>
                <th className="text-right px-2 py-1.5 font-medium w-14">Conf.</th>
                <th className="w-8" />
              </tr>
            </thead>
            <tbody>
              {rows.map((r, i) => (
                <tr key={i} className="border-t border-violet-900/40 text-violet-50">
                  <td className="px-2 py-1">
                    <input
                      value={r.design}
                      onChange={(e) => updateRow(i, { design: e.target.value })}
                      className="w-full bg-transparent border-b border-violet-700/30 px-0.5 py-0.5 font-mono text-[#e5c07b] outline-none focus:border-violet-400"
                    />
                  </td>
                  <td className="px-2 py-1">
                    <input
                      type="number"
                      min={0}
                      value={r.stock}
                      onChange={(e) =>
                        updateRow(i, { stock: parseInt(e.target.value, 10) || 0 })
                      }
                      className="w-full text-right bg-transparent border-b border-violet-700/30 px-0.5 py-0.5 outline-none focus:border-violet-400"
                    />
                  </td>
                  <td className="px-2 py-1">
                    <input
                      type="number"
                      min={0}
                      value={r.sold}
                      onChange={(e) =>
                        updateRow(i, { sold: parseInt(e.target.value, 10) || 0 })
                      }
                      className="w-full text-right bg-transparent border-b border-violet-700/30 px-0.5 py-0.5 outline-none focus:border-violet-400"
                    />
                  </td>
                  <td className="px-2 py-1 text-right text-violet-300/60">
                    {r.confidence != null ? `${Math.round(r.confidence * 100)}%` : '—'}
                  </td>
                  <td className="px-1 py-1">
                    <button
                      type="button"
                      onClick={() => removeRow(i)}
                      className="p-1 text-violet-400/60 hover:text-rose-300 transition"
                      aria-label="Remove row"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr className="border-t border-violet-700/40 bg-violet-950/40 text-violet-200/80">
                <td className="px-2 py-1.5 font-medium">Sum</td>
                <td
                  className={`px-2 py-1.5 text-right font-mono ${stockOk ? 'text-emerald-400' : 'text-rose-400'}`}
                >
                  {stockSum} / {targetStock}
                </td>
                <td
                  className={`px-2 py-1.5 text-right font-mono ${soldOk ? 'text-emerald-400' : 'text-rose-400'}`}
                >
                  {soldSum} / {targetSold}
                </td>
                <td colSpan={2} />
              </tr>
            </tfoot>
          </table>
        </div>
      )}

      {rows.length > 0 && (
        <div className="flex items-center justify-between gap-2">
          <p className="text-[10px] text-violet-200/50">
            Apply করলে records-এ <code className="text-violet-200/80">0.02 · NP7SD1</code> style keys যোগ হবে
          </p>
          <button
            type="button"
            onClick={handleApply}
            className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 px-3 py-1.5 text-xs font-semibold text-white transition"
          >
            {applied ? <Check className="w-3.5 h-3.5" /> : null}
            {applied ? 'Applied' : 'Apply to upload'}
          </button>
        </div>
      )}
    </div>
  );
};
