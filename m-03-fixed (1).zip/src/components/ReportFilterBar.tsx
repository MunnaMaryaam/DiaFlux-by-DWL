import React, { useMemo, useState, useEffect } from 'react';
import {
  Building2,
  Gem,
  Filter,
  X,
  Search,
  Layers,
  ChevronDown,
  ChevronUp,
  Settings2,
} from 'lucide-react';
import { RawInventoryRecord } from '../types';

export interface ReportFilters {
  branchId: string;
  ctsFrom: string;
  ctsTo: string;
  mainCategory: string;
  subCategory: string;
}

interface ReportFilterBarProps {
  rawRecords: RawInventoryRecord[];
  filters: ReportFilters;
  onFiltersChange: (f: ReportFilters) => void;
  filteredCount: number;
  totalCount: number;
}

/** Parse weight/carat string to number */
export function parseCaratValue(weight: string): number | null {
  if (!weight) return null;
  // Support composite keys "0.05 · NP7SD1"
  const base = String(weight).split('·')[0].trim();
  const cleaned = base.replace(/[^\d.]/g, '');
  const n = parseFloat(cleaned);
  return isNaN(n) ? null : n;
}

const isWarehouseBranchName = (branch: string) => {
  const lower = (branch || '').toLowerCase().trim();
  return (
    lower === 'dwl' ||
    lower.startsWith('dwl ') ||
    lower.endsWith(' dwl') ||
    lower.includes('warehouse') ||
    lower.includes('central') ||
    lower.includes('hub')
  );
};

export function applyReportFilters(
  records: RawInventoryRecord[],
  filters: ReportFilters
): RawInventoryRecord[] {
  const fromN = filters.ctsFrom.trim() !== '' ? parseFloat(filters.ctsFrom) : null;
  const toN = filters.ctsTo.trim() !== '' ? parseFloat(filters.ctsTo) : null;
  const branchQ = filters.branchId.trim().toLowerCase();
  const mainCat = filters.mainCategory.trim().toLowerCase();
  const subCat = filters.subCategory.trim().toLowerCase();

  return records.filter((r) => {
    const isWh = isWarehouseBranchName(r.branch);

    if (branchQ) {
      const b = (r.branch || '').toLowerCase();
      if (!isWh && !b.includes(branchQ) && b !== branchQ) return false;
    }

    if (fromN != null || toN != null) {
      const w = parseCaratValue(r.weight);
      if (w == null) return false;
      if (fromN != null && w < fromN) return false;
      if (toN != null && w > toN) return false;
    }

    if (mainCat) {
      const c = (r.category || '').toLowerCase();
      if (!c.includes(mainCat)) return false;
    }

    if (subCat) {
      const hay = `${r.variant || ''} ${r.itemName || ''} ${r.itemCode || ''}`.toLowerCase();
      if (!hay.includes(subCat)) return false;
    }

    return true;
  });
}

export const EMPTY_FILTERS: ReportFilters = {
  branchId: '',
  ctsFrom: '',
  ctsTo: '',
  mainCategory: '',
  subCategory: '',
};

const fieldCls =
  'w-full h-8 bg-white border border-[#89919a] px-2 text-[12px] text-[#32363a] focus:outline-none focus:border-[#0854a0] focus:ring-1 focus:ring-[#0854a0]/25';

/**
 * SAP Fiori–style filter bar:
 * compact fields, Go / Adapt Filters / Clear, active filter chips
 */
export const ReportFilterBar: React.FC<ReportFilterBarProps> = ({
  rawRecords,
  filters,
  onFiltersChange,
  filteredCount,
  totalCount,
}) => {
  const [draft, setDraft] = useState<ReportFilters>(filters);
  const [expanded, setExpanded] = useState(false);

  useEffect(() => {
    setDraft(filters);
  }, [filters]);

  const branchOptions = useMemo(() => {
    const set = new Set<string>();
    rawRecords.forEach((r) => {
      if (r.branch) set.add(r.branch);
    });
    return Array.from(set).sort((a, b) => a.localeCompare(b));
  }, [rawRecords]);

  const categoryOptions = useMemo(() => {
    const set = new Set<string>();
    rawRecords.forEach((r) => {
      if (r.category) set.add(r.category);
    });
    return Array.from(set).sort((a, b) => a.localeCompare(b));
  }, [rawRecords]);

  const caratOptions = useMemo(() => {
    const set = new Set<string>();
    rawRecords.forEach((r) => {
      if (r.weight) {
        const base = String(r.weight).split('·')[0].trim();
        if (base) set.add(base);
      }
    });
    return Array.from(set).sort((a, b) => {
      const na = parseFloat(a);
      const nb = parseFloat(b);
      if (!isNaN(na) && !isNaN(nb)) return na - nb;
      return a.localeCompare(b);
    });
  }, [rawRecords]);

  const styleOptions = useMemo(() => {
    const set = new Set<string>();
    rawRecords.forEach((r) => {
      if (r.itemCode) set.add(r.itemCode);
      if (r.variant) set.add(r.variant);
    });
    return Array.from(set).sort((a, b) => a.localeCompare(b)).slice(0, 300);
  }, [rawRecords]);

  const activeChips: { key: keyof ReportFilters; label: string }[] = [];
  if (filters.branchId) activeChips.push({ key: 'branchId', label: `Branch: ${filters.branchId}` });
  if (filters.ctsFrom || filters.ctsTo) {
    activeChips.push({
      key: 'ctsFrom',
      label: `Cts: ${filters.ctsFrom || '…'} – ${filters.ctsTo || '…'}`,
    });
  }
  if (filters.mainCategory) activeChips.push({ key: 'mainCategory', label: `Category: ${filters.mainCategory}` });
  if (filters.subCategory) activeChips.push({ key: 'subCategory', label: `Style: ${filters.subCategory}` });

  const hasActive = activeChips.length > 0;

  const handleGo = () => onFiltersChange({ ...draft });

  const handleClear = () => {
    setDraft(EMPTY_FILTERS);
    onFiltersChange(EMPTY_FILTERS);
  };

  const removeChip = (key: keyof ReportFilters) => {
    const next = { ...filters };
    if (key === 'ctsFrom') {
      next.ctsFrom = '';
      next.ctsTo = '';
    } else {
      next[key] = '';
    }
    setDraft(next);
    onFiltersChange(next);
  };

  const onKey = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') handleGo();
  };

  return (
    <div
      id="sap-filter-bar"
      className="bg-[#edf0f4] border border-[#d9d9d9] text-[#32363a]"
      role="search"
      aria-label="SAP-style filter bar"
    >
      {/* Header strip */}
      <div className="flex items-center justify-between px-3 py-1.5 border-b border-[#d9d9d9] bg-[#f7f7f7]">
        <div className="flex items-center gap-2 text-[12px] font-semibold text-[#32363a]">
          <Filter className="w-3.5 h-3.5 text-[#0854a0]" />
          <span>Filter</span>
          <span className="font-normal text-[#6a6d70]">
            · {filteredCount.toLocaleString()} of {totalCount.toLocaleString()}
            {hasActive ? ' (filtered)' : ''}
          </span>
        </div>
        <button
          type="button"
          onClick={() => setExpanded((v) => !v)}
          className="inline-flex items-center gap-1 text-[11px] font-semibold text-[#0854a0] hover:underline"
        >
          <Settings2 className="w-3 h-3" />
          Adapt Filters
          {expanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
        </button>
      </div>

      {/* Primary filter row — always visible (SAP compact) */}
      <div className="px-3 py-2 flex flex-wrap items-end gap-x-3 gap-y-2">
        {/* Branch */}
        <div className="min-w-[120px] flex-1 max-w-[180px]">
          <label className="block text-[11px] text-[#6a6d70] mb-0.5">
            <Building2 className="w-3 h-3 inline mr-0.5 text-[#0854a0]" />
            Branch
          </label>
          <input
            type="text"
            list="sap-branch-options"
            value={draft.branchId}
            onChange={(e) => setDraft({ ...draft, branchId: e.target.value })}
            onKeyDown={onKey}
            placeholder="All"
            className={fieldCls}
          />
          <datalist id="sap-branch-options">
            {branchOptions.map((b) => (
              <option key={b} value={b} />
            ))}
          </datalist>
        </div>

        {/* Cts From */}
        <div className="min-w-[90px] w-[110px]">
          <label className="block text-[11px] text-[#6a6d70] mb-0.5">
            <Gem className="w-3 h-3 inline mr-0.5 text-[#0854a0]" />
            Cts From
          </label>
          <input
            type="text"
            list="sap-cts-from"
            inputMode="decimal"
            value={draft.ctsFrom}
            onChange={(e) => setDraft({ ...draft, ctsFrom: e.target.value })}
            onKeyDown={onKey}
            placeholder="0.02"
            className={fieldCls}
          />
          <datalist id="sap-cts-from">
            {caratOptions.map((c) => (
              <option key={`f-${c}`} value={c} />
            ))}
          </datalist>
        </div>

        {/* Cts To */}
        <div className="min-w-[90px] w-[110px]">
          <label className="block text-[11px] text-[#6a6d70] mb-0.5">Cts To</label>
          <input
            type="text"
            list="sap-cts-to"
            inputMode="decimal"
            value={draft.ctsTo}
            onChange={(e) => setDraft({ ...draft, ctsTo: e.target.value })}
            onKeyDown={onKey}
            placeholder="0.20"
            className={fieldCls}
          />
          <datalist id="sap-cts-to">
            {caratOptions.map((c) => (
              <option key={`t-${c}`} value={c} />
            ))}
          </datalist>
        </div>

        {/* Category — primary when expanded or always if space */}
        <div className="min-w-[140px] flex-1 max-w-[220px]">
          <label className="block text-[11px] text-[#6a6d70] mb-0.5">
            <Layers className="w-3 h-3 inline mr-0.5 text-[#0854a0]" />
            Category
          </label>
          <input
            type="text"
            list="sap-cat-options"
            value={draft.mainCategory}
            onChange={(e) => setDraft({ ...draft, mainCategory: e.target.value })}
            onKeyDown={onKey}
            placeholder="All categories"
            className={fieldCls}
          />
          <datalist id="sap-cat-options">
            {categoryOptions.map((c) => (
              <option key={c} value={c} />
            ))}
          </datalist>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-1.5 pb-px">
          <button
            type="button"
            onClick={handleGo}
            className="h-8 px-4 bg-[#0854a0] hover:bg-[#0a6ed1] text-white text-[12px] font-semibold border border-[#0854a0] inline-flex items-center gap-1.5"
          >
            <Search className="w-3.5 h-3.5" />
            Go
          </button>
          <button
            type="button"
            onClick={handleClear}
            disabled={!hasActive && !draft.branchId && !draft.ctsFrom && !draft.ctsTo && !draft.mainCategory && !draft.subCategory}
            className="h-8 px-3 bg-white border border-[#89919a] text-[12px] font-semibold text-[#32363a] hover:bg-[#f5f6f7] disabled:opacity-40 inline-flex items-center gap-1"
          >
            <X className="w-3.5 h-3.5" />
            Clear
          </button>
        </div>
      </div>

      {/* Adapted / secondary filters */}
      {expanded && (
        <div className="px-3 pb-2 flex flex-wrap items-end gap-x-3 gap-y-2 border-t border-[#e5e5e5] pt-2 bg-[#fafafa]">
          <div className="min-w-[140px] flex-1 max-w-[240px]">
            <label className="block text-[11px] text-[#6a6d70] mb-0.5">Style / Design</label>
            <input
              type="text"
              list="sap-style-options"
              value={draft.subCategory}
              onChange={(e) => setDraft({ ...draft, subCategory: e.target.value })}
              onKeyDown={onKey}
              placeholder="NP7SD1, NP7SD10…"
              className={fieldCls}
            />
            <datalist id="sap-style-options">
              {styleOptions.map((s) => (
                <option key={s} value={s} />
              ))}
            </datalist>
          </div>
          <p className="text-[10px] text-[#6a6d70] max-w-md leading-snug self-center">
            Style filter matches design codes from Oracle style sheet filenames (e.g. NP7SD1).
            Category sheet rows without style are excluded when a style is set.
          </p>
        </div>
      )}

      {/* Active filter chips */}
      {hasActive && (
        <div className="px-3 py-1.5 border-t border-[#e5e5e5] bg-white flex flex-wrap items-center gap-1.5">
          <span className="text-[10px] font-semibold text-[#6a6d70] mr-1">Active:</span>
          {activeChips.map((chip) => (
            <button
              key={chip.key}
              type="button"
              onClick={() => removeChip(chip.key)}
              className="inline-flex items-center gap-1 h-6 px-2 text-[11px] bg-[#e8f0fe] text-[#0854a0] border border-[#b6d4fe] hover:bg-[#d0e3fc]"
              title="Remove filter"
            >
              {chip.label}
              <X className="w-3 h-3" />
            </button>
          ))}
        </div>
      )}
    </div>
  );
};
