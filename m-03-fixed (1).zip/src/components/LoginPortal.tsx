import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  AlertCircle,
  Check,
  ChevronRight,
  Eye,
  EyeOff,
  Fingerprint,
  Loader2,
  Lock,
  Settings2,
  ShieldCheck,
  User,
  WifiOff,
  X,
} from 'lucide-react';
import { AuthUser } from '../types';
import { authenticateUser, requestPasswordRecovery, requestSignup } from '../utils/authEngine';

interface LoginPortalProps {
  onLoginSuccess: (user: AuthUser) => void;
}

type Mode = 'login' | 'signup' | 'forgot';
type ServerStatus = 'checking' | 'online' | 'offline';
type VideoQuality = '1080p' | '720p' | '480p';

const VIDEO_SOURCES: Record<VideoQuality, string> = {
  '1080p': '/dw-login-bg-1080.mp4',
  '720p': '/dw-login-bg-720.mp4',
  '480p': '/dw-login-bg-480.mp4',
};

const QUALITY_OPTIONS: { id: VideoQuality; label: string }[] = [
  { id: '1080p', label: '1080p' },
  { id: '720p', label: '720p' },
  { id: '480p', label: '480p' },
];

const QUALITY_STORAGE_KEY = 'dw-login-video-quality';

function readSavedQuality(): VideoQuality {
  try {
    const v = localStorage.getItem(QUALITY_STORAGE_KEY);
    if (v === '1080p' || v === '720p' || v === '480p') return v;
  } catch {
    /* ignore */
  }
  return '1080p';
}

export const LoginPortal: React.FC<LoginPortalProps> = ({ onLoginSuccess }) => {
  const [mode, setMode] = useState<Mode>('login');
  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [agreedToTerms, setAgreedToTerms] = useState(true);
  const [message, setMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [serverStatus, setServerStatus] = useState<ServerStatus>('checking');
  const [showLoginCard, setShowLoginCard] = useState(false);
  const [videoQuality, setVideoQuality] = useState<VideoQuality>(readSavedQuality);
  const [showQualityMenu, setShowQualityMenu] = useState(false);

  // ── Mouse-parallax for the background video ──
  const stageRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const [parallax, setParallax] = useState({ x: 0, y: 0 });

  const handleStageMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const el = stageRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const nx = (e.clientX - rect.left) / rect.width - 0.5;
    const ny = (e.clientY - rect.top) / rect.height - 0.5;
    setParallax({
      x: nx * 36,
      y: ny * 24,
    });
  };

  const handleStageMouseLeave = () => {
    setParallax({ x: 0, y: 0 });
  };

  const changeVideoQuality = (q: VideoQuality) => {
    if (q === videoQuality) {
      setShowQualityMenu(false);
      return;
    }
    const video = videoRef.current;
    const t = video && !Number.isNaN(video.currentTime) ? video.currentTime : 0;
    setVideoQuality(q);
    try {
      localStorage.setItem(QUALITY_STORAGE_KEY, q);
    } catch {
      /* ignore */
    }
    setShowQualityMenu(false);
    // Restore position after source swap (handled in effect via data attr)
    requestAnimationFrame(() => {
      const v = videoRef.current;
      if (v) {
        v.dataset.resumeAt = String(t);
      }
    });
  };

  // ── Reliable autoplay (browsers block unmuted autoplay; also retry on visibility) ──
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    video.muted = true;
    video.defaultMuted = true;
    video.setAttribute('muted', '');
    video.setAttribute('playsinline', '');
    video.playsInline = true;

    const tryPlay = () => {
      const resumeAt = video.dataset.resumeAt;
      if (resumeAt) {
        const t = parseFloat(resumeAt);
        if (!Number.isNaN(t) && t > 0) {
          try {
            video.currentTime = t;
          } catch {
            /* ignore seek errors while loading */
          }
        }
        delete video.dataset.resumeAt;
      }
      const p = video.play();
      if (p && typeof p.then === 'function') {
        p.catch(() => {
          // Autoplay blocked — retry on next user gesture / visibility
        });
      }
    };

    tryPlay();

    const onVisibility = () => {
      if (document.visibilityState === 'visible' && video.paused) tryPlay();
    };
    const onCanPlay = () => tryPlay();
    const onLoaded = () => tryPlay();

    document.addEventListener('visibilitychange', onVisibility);
    video.addEventListener('canplay', onCanPlay);
    video.addEventListener('loadeddata', onLoaded);

    // One-shot unlock on first pointer/keydown (strict autoplay policies)
    const unlock = () => {
      tryPlay();
      window.removeEventListener('pointerdown', unlock);
      window.removeEventListener('keydown', unlock);
      window.removeEventListener('touchstart', unlock);
    };
    window.addEventListener('pointerdown', unlock, { once: true });
    window.addEventListener('keydown', unlock, { once: true });
    window.addEventListener('touchstart', unlock, { once: true });

    return () => {
      document.removeEventListener('visibilitychange', onVisibility);
      video.removeEventListener('canplay', onCanPlay);
      video.removeEventListener('loadeddata', onLoaded);
      window.removeEventListener('pointerdown', unlock);
      window.removeEventListener('keydown', unlock);
      window.removeEventListener('touchstart', unlock);
    };
  }, [videoQuality]);

  // Close quality menu on outside click / Escape
  useEffect(() => {
    if (!showQualityMenu) return;
    const onDoc = (e: MouseEvent) => {
      const t = e.target as HTMLElement;
      if (!t.closest('[data-quality-picker]')) setShowQualityMenu(false);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setShowQualityMenu(false);
    };
    document.addEventListener('mousedown', onDoc);
    window.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDoc);
      window.removeEventListener('keydown', onKey);
    };
  }, [showQualityMenu]);

  useEffect(() => {
    let cancelled = false;
    const checkHealth = async () => {
      try {
        const res = await fetch('/api/health', { credentials: 'include' });
        if (!cancelled) setServerStatus(res.ok ? 'online' : 'offline');
      } catch {
        if (!cancelled) setServerStatus('offline');
      }
    };
    checkHealth();
    return () => {
      cancelled = true;
    };
  }, []);

  // Close login card on Escape
  useEffect(() => {
    if (!showLoginCard) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setShowLoginCard(false);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [showLoginCard]);

  const clearNotice = () => {
    setMessage('');
    setErrorMessage('');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    clearNotice();
    if (mode !== 'login' && !agreedToTerms) {
      setErrorMessage('Please accept the access terms to continue.');
      return;
    }
    setIsLoading(true);

    try {
      if (mode === 'login') {
        const result = await authenticateUser(username, password);
        if (result.success && result.user) {
          onLoginSuccess(result.user);
        } else {
          setErrorMessage(result.error || 'Invalid username or password.');
        }
      } else if (mode === 'signup') {
        const result = await requestSignup({ username, name, password });
        if (result.success) {
          setMessage(result.message || 'Account request submitted.');
          setMode('login');
          setPassword('');
        } else {
          setErrorMessage(result.error || 'Could not create account request.');
        }
      } else {
        const result = await requestPasswordRecovery(username);
        if (result.success) {
          setMessage(result.message || 'Recovery request submitted.');
        } else {
          setErrorMessage(result.error || 'Could not submit recovery request.');
        }
      }
    } finally {
      setIsLoading(false);
    }
  };

  const switchMode = (next: Mode) => {
    setMode(next);
    setPassword('');
    clearNotice();
  };

  const openLogin = () => {
    setMode('login');
    clearNotice();
    setShowLoginCard(true);
  };

  const heading =
    mode === 'login' ? 'Sign In' : mode === 'signup' ? 'Request Access' : 'Recover Account';

  const subheading =
    mode === 'login'
      ? 'Authenticate to access the intelligence console'
      : mode === 'signup'
        ? 'Submit details for system owner approval'
        : 'Enter username to request a password reset';

  const submitLabel =
    mode === 'login' ? 'Sign In' : mode === 'signup' ? 'Submit Request' : 'Send Recovery Link';

  return (
    <div
      ref={stageRef}
      onMouseMove={handleStageMouseMove}
      onMouseLeave={handleStageMouseLeave}
      className="relative min-h-screen w-full font-body overflow-hidden flex flex-col bg-[#04070f]"
    >
      {/* ══════════════ FULL-BLEED BACKGROUND: Diamond World ring video ══════════════ */}
      <motion.video
        key={videoQuality}
        ref={videoRef}
        src={VIDEO_SOURCES[videoQuality]}
        poster="/dw-login-bg-new-poster.jpg"
        autoPlay
        loop
        muted
        playsInline
        preload="auto"
        disablePictureInPicture
        disableRemotePlayback
        animate={{ x: parallax.x, y: parallax.y }}
        transition={{ type: 'spring', stiffness: 60, damping: 18, mass: 0.8 }}
        className="pointer-events-none absolute -inset-[2%] h-[104%] w-[104%] object-cover"
        style={{ filter: 'brightness(0.7) saturate(1.15) contrast(1.05)' }}
      />
      {/* Soft vignette — keeps edges dark, no text overlays in the background */}
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            'radial-gradient(ellipse 85% 75% at 50% 45%, transparent 25%, rgba(4,7,15,0.25) 65%, rgba(4,7,15,0.7) 100%),' +
            'linear-gradient(180deg, rgba(4,7,15,0.4) 0%, transparent 15%, transparent 85%, rgba(4,7,15,0.5) 100%)',
        }}
      />

      {/* ══════════════ TOP BAR — logo left, Log in button top-right (OpenAI Astra style) ══════════════ */}
      <header className="relative z-20 w-full px-5 sm:px-8 lg:px-10 pt-4 sm:pt-5 flex items-center justify-between">
        {/* Brand mark */}
        <div className="flex items-center gap-3">
          <div
            className="relative h-11 w-11 sm:h-12 sm:w-12 rounded-xl p-1.5 shadow-[0_4px_20px_rgba(0,0,0,0.6)] ring-1 border shrink-0"
            style={{
              backgroundColor: '#ffffff',
              borderColor: 'rgba(223, 186, 107, 0.55)',
              boxShadow: '0 0 15px rgba(223, 186, 107, 0.25)',
            }}
          >
            <img
              src="/diamond-world-logo-cutout.png"
              alt="Diamond World"
              className="h-full w-full object-contain"
            />
          </div>
          <div className="hidden sm:block">
            <span className="font-heading text-sm sm:text-base font-semibold tracking-wide text-white block leading-tight">
              Diamond World LTD
            </span>
            <span className="font-tagline italic text-[11px] text-[#dfba6b] block -mt-0.5">
              the art of beauty
            </span>
          </div>
        </div>

        {/* Top-right actions — Log in + optional CTA */}
        <div className="flex items-center gap-2.5 sm:gap-3">
          <button
            type="button"
            onClick={openLogin}
            className="inline-flex items-center justify-center rounded-full border border-white/25 bg-white/5 px-4 sm:px-5 py-2 text-sm font-medium text-white/95 backdrop-blur-md transition hover:bg-white/15 hover:border-white/40 active:scale-[0.98]"
          >
            Log in
          </button>
          <button
            type="button"
            onClick={openLogin}
            className="inline-flex items-center justify-center rounded-full bg-white px-4 sm:px-5 py-2 text-sm font-semibold text-[#0a0a0a] transition hover:bg-white/90 active:scale-[0.98]"
          >
            Enter Console
          </button>
        </div>
      </header>

      {/* ══════════════ HERO — clean center, no background text ══════════════ */}
      <div className="relative z-10 flex-1 flex flex-col items-center justify-center px-4 pointer-events-none">
        {/* Intentionally empty / minimal so the video is the hero — no large side text */}
      </div>

      {/* ══════════════ VIDEO QUALITY PICKER ══════════════ */}
      <div
        data-quality-picker
        className="absolute z-30 bottom-16 sm:bottom-20 left-4 sm:left-6"
      >
        <button
          type="button"
          onClick={() => setShowQualityMenu((v) => !v)}
          className="inline-flex items-center gap-1.5 rounded-full border border-white/20 bg-black/40 px-3 py-1.5 text-[11px] font-medium text-white/90 backdrop-blur-md transition hover:bg-black/55 hover:border-white/35"
          aria-expanded={showQualityMenu}
          aria-haspopup="listbox"
          title="Video quality"
        >
          <Settings2 className="h-3.5 w-3.5 text-[#dfba6b]" />
          <span>{videoQuality}</span>
        </button>
        <AnimatePresence>
          {showQualityMenu && (
            <motion.ul
              initial={{ opacity: 0, y: 6, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 4, scale: 0.98 }}
              transition={{ duration: 0.15 }}
              role="listbox"
              aria-label="Video quality"
              className="absolute bottom-full left-0 mb-2 min-w-[7.5rem] overflow-hidden rounded-xl border border-white/15 bg-[#0c0a14]/95 py-1 shadow-xl backdrop-blur-xl"
            >
              {QUALITY_OPTIONS.map((opt) => (
                <li key={opt.id} role="option" aria-selected={opt.id === videoQuality}>
                  <button
                    type="button"
                    onClick={() => changeVideoQuality(opt.id)}
                    className={`flex w-full items-center justify-between gap-3 px-3 py-2 text-left text-xs transition ${
                      opt.id === videoQuality
                        ? 'bg-white/10 text-[#dfba6b] font-semibold'
                        : 'text-white/85 hover:bg-white/8'
                    }`}
                  >
                    <span>{opt.label}</span>
                    {opt.id === videoQuality && <Check className="h-3.5 w-3.5 shrink-0" />}
                  </button>
                </li>
              ))}
            </motion.ul>
          )}
        </AnimatePresence>
      </div>

      {/* ══════════════ FOOTER ══════════════ */}
      <footer className="relative z-10 w-full px-6 sm:px-10 py-4 text-[10px] text-slate-300/50 flex flex-col items-center gap-1 text-center">
        <p>© {new Date().getFullYear()} Diamond World LTD · Enterprise Stock Intelligence</p>
        <span>
          Developed by <strong className="text-slate-200/70 font-medium">MSH (Data Analytics)</strong>
        </span>
      </footer>

      {/* ══════════════ LOGIN CARD OVERLAY — appears on Log in click ══════════════ */}
      <AnimatePresence>
        {showLoginCard && (
          <>
            {/* Backdrop */}
            <motion.div
              key="backdrop"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.25 }}
              className="fixed inset-0 z-40 bg-black/55 backdrop-blur-[2px]"
              onClick={() => setShowLoginCard(false)}
            />

            {/* Card container */}
            <motion.div
              key="card-wrap"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 flex items-center justify-center px-4 py-8 pointer-events-none"
            >
              <motion.div
                initial={{ opacity: 0, scale: 0.94, y: 16 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.96, y: 10 }}
                transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
                className="pointer-events-auto w-full max-w-sm relative"
                onClick={(e) => e.stopPropagation()}
              >
                <div
                  style={{
                    backgroundColor: 'rgba(18, 12, 31, 0.55)',
                    borderColor: 'rgba(255, 255, 255, 0.16)',
                    boxShadow:
                      '0 25px 80px rgba(0, 0, 0, 0.55), 0 0 60px rgba(223, 186, 107, 0.08), inset 0 1px 0 rgba(255,255,255,0.08)',
                  }}
                  className="relative rounded-3xl border backdrop-blur-2xl backdrop-saturate-150 p-6 sm:p-8"
                >
                  {/* Close button */}
                  <button
                    type="button"
                    aria-label="Close"
                    onClick={() => setShowLoginCard(false)}
                    className="absolute top-4 right-4 h-8 w-8 rounded-full flex items-center justify-center text-slate-300/80 hover:text-white hover:bg-white/10 transition"
                  >
                    <X className="h-4 w-4" />
                  </button>

                  {/* Corner Gold accent */}
                  <div className="pointer-events-none absolute top-0 left-8 right-8 h-px bg-gradient-to-r from-transparent via-[#dfba6b] to-transparent opacity-80" />

                  {/* Mode title + status header */}
                  <div className="mb-6 flex items-start justify-between gap-3 pr-8">
                    <div className="text-left">
                      <h2 className="font-display text-xl sm:text-2xl font-semibold text-white tracking-tight">
                        {heading}
                      </h2>
                      <p className="text-xs text-slate-300/80 mt-1 font-body">{subheading}</p>
                    </div>
                    <div
                      className="h-9 w-9 rounded-xl flex items-center justify-center shadow-inner shrink-0 border"
                      style={{
                        background:
                          'linear-gradient(135deg, rgba(223, 186, 107, 0.25) 0%, rgba(255,255,255,0.06) 100%)',
                        borderColor: 'rgba(223, 186, 107, 0.5)',
                        color: '#dfba6b',
                      }}
                    >
                      <Lock className="h-4 w-4" />
                    </div>
                  </div>

                  {/* Notices */}
                  <AnimatePresence mode="wait">
                    {serverStatus === 'offline' && (
                      <motion.div
                        key="offline"
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className="mb-4 flex items-start gap-2 rounded-xl border border-amber-400/30 bg-amber-400/10 p-3 text-xs text-amber-200"
                      >
                        <WifiOff className="mt-0.5 h-4 w-4 shrink-0" />
                        <span>Server is offline. Running on local resilient fallback.</span>
                      </motion.div>
                    )}
                    {message && (
                      <motion.div
                        key="message"
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className="mb-4 flex items-start gap-2 rounded-xl border border-emerald-400/30 bg-emerald-400/10 p-3 text-xs text-emerald-200"
                      >
                        <Check className="mt-0.5 h-4 w-4 shrink-0" />
                        <span>{message}</span>
                      </motion.div>
                    )}
                    {errorMessage && (
                      <motion.div
                        key="error"
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className="mb-4 flex items-start gap-2 rounded-xl border border-rose-400/30 bg-rose-400/10 p-3 text-xs text-rose-200"
                      >
                        <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
                        <span>{errorMessage}</span>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  {/* Form */}
                  <form onSubmit={handleSubmit} className="space-y-4">
                    {mode === 'signup' && (
                      <div>
                        <label className="block text-[10px] font-semibold text-[#c8cddb] mb-1.5 uppercase tracking-wider">
                          Full Name
                        </label>
                        <input
                          required
                          type="text"
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          placeholder="Enter your full name"
                          autoComplete="name"
                          className="w-full rounded-xl border border-white/20 bg-white/10 px-3.5 py-2.5 text-sm text-white placeholder:text-slate-300/50 outline-none focus:border-[#dfba6b]/70 focus:bg-white/[0.14] focus:ring-2 focus:ring-[#dfba6b]/25 transition"
                        />
                      </div>
                    )}

                    <div>
                      <label className="flex items-center gap-1.5 text-[10px] font-semibold text-[#c8cddb] mb-1.5 uppercase tracking-wider">
                        <User className="h-3 w-3 text-[#dfba6b]" /> Username
                      </label>
                      <input
                        required
                        type="text"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        placeholder="Enter your username"
                        autoComplete="username"
                        className="w-full rounded-xl border border-white/20 bg-white/10 px-3.5 py-2.5 text-sm text-white placeholder:text-slate-300/50 outline-none focus:border-[#dfba6b]/70 focus:bg-white/[0.14] focus:ring-2 focus:ring-[#dfba6b]/25 transition"
                      />
                    </div>

                    {mode !== 'forgot' && (
                      <div>
                        <label className="flex items-center gap-1.5 text-[10px] font-semibold text-[#c8cddb] mb-1.5 uppercase tracking-wider">
                          <Lock className="h-3 w-3 text-[#dfba6b]" />
                          {mode === 'signup' ? 'Create Password' : 'Password'}
                        </label>
                        <div className="relative">
                          <input
                            required
                            type={showPassword ? 'text' : 'password'}
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            placeholder={
                              mode === 'signup' ? 'At least 4 characters' : 'Enter your password'
                            }
                            autoComplete={mode === 'signup' ? 'new-password' : 'current-password'}
                            className="w-full rounded-xl border border-white/20 bg-white/10 px-3.5 py-2.5 pr-11 text-sm text-white placeholder:text-slate-300/50 outline-none focus:border-[#dfba6b]/70 focus:bg-white/[0.14] focus:ring-2 focus:ring-[#dfba6b]/25 transition"
                          />
                          <button
                            type="button"
                            aria-label={showPassword ? 'Hide password' : 'Show password'}
                            onClick={() => setShowPassword((v) => !v)}
                            className="absolute inset-y-0 right-0 flex w-11 items-center justify-center text-slate-300/70 hover:text-white transition"
                          >
                            {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                          </button>
                        </div>
                      </div>
                    )}

                    {mode === 'login' && (
                      <div className="flex items-center justify-between pt-0.5">
                        <label className="flex cursor-pointer items-center gap-2">
                          <input
                            type="checkbox"
                            checked={rememberMe}
                            onChange={(e) => setRememberMe(e.target.checked)}
                            className="h-3.5 w-3.5 rounded border-white/30 bg-white/10 accent-[#dfba6b]"
                          />
                          <span className="text-xs text-slate-200/80">Remember me</span>
                        </label>
                        <button
                          type="button"
                          onClick={() => switchMode('forgot')}
                          className="text-xs font-medium text-[#dfba6b] hover:text-[#e5c07b] hover:underline transition"
                        >
                          Forgot password?
                        </button>
                      </div>
                    )}

                    {mode !== 'login' && (
                      <label className="flex cursor-pointer items-center gap-2">
                        <input
                          type="checkbox"
                          checked={agreedToTerms}
                          onChange={(e) => setAgreedToTerms(e.target.checked)}
                          className="h-3.5 w-3.5 rounded border-white/30 bg-white/10 accent-[#dfba6b]"
                        />
                        <span className="text-xs text-slate-200/80">I agree to the access terms.</span>
                      </label>
                    )}

                    <button
                      type="submit"
                      disabled={isLoading}
                      style={{
                        background: 'var(--btn-gold-gradient, linear-gradient(90deg, #e5c07b, #c49a45))',
                        boxShadow: '0 10px 30px rgba(196, 154, 69, 0.35)',
                      }}
                      className="group relative w-full overflow-hidden rounded-xl text-[#120c1f] font-bold text-sm py-3 ring-1 ring-[#e5c07b]/70 transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 hover:brightness-105 active:scale-[0.99]"
                    >
                      <span className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/30 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
                      {isLoading ? (
                        <Loader2 className="h-4 w-4 animate-spin text-[#120c1f]" />
                      ) : (
                        <Fingerprint className="h-4 w-4 text-[#120c1f]" />
                      )}
                      {isLoading ? 'Authenticating…' : submitLabel}
                    </button>
                  </form>

                  {/* Mode switcher */}
                  <div className="mt-5 pt-4 border-t border-white/[0.14]">
                    {mode === 'login' ? (
                      <p className="text-center text-xs text-slate-300/70">
                        Don&apos;t have an account?{' '}
                        <button
                          type="button"
                          onClick={() => switchMode('signup')}
                          className="font-semibold text-[#dfba6b] hover:text-[#e5c07b] hover:underline transition"
                        >
                          Request access
                        </button>
                      </p>
                    ) : (
                      <p className="text-center text-xs text-slate-300/70">
                        <button
                          type="button"
                          onClick={() => switchMode('login')}
                          className="inline-flex items-center gap-1 font-semibold text-[#dfba6b] hover:text-[#e5c07b] hover:underline transition"
                        >
                          <ChevronRight className="h-3 w-3 rotate-180" />
                          Back to sign in
                        </button>
                      </p>
                    )}
                  </div>

                  {/* Security info footer */}
                  <div className="mt-5 pt-3 border-t border-white/[0.14] flex items-center justify-center gap-2 text-[10px] text-slate-300/70 font-mono uppercase tracking-wider">
                    <ShieldCheck className="h-3.5 w-3.5 text-[#dfba6b]" />
                    <span>Encrypted 256-Bit SSL · RBAC Enforced</span>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
};
