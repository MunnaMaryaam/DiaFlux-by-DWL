import React from 'react';

interface CinematicMotionBackgroundProps {
  videoSrc?: string;
  posterSrc?: string;
  /** true (default) = covers the whole viewport (fixed). false = fills its own
   * relatively-positioned parent instead — used for the split-screen video panel. */
  fullBleed?: boolean;
  /** Lighter vignette so the video itself stays the focal point (split-panel use). */
  softVignette?: boolean;
}

export const CinematicMotionBackground: React.FC<CinematicMotionBackgroundProps> = ({
  videoSrc = '/dw-login-bg.mp4',
  posterSrc = '/dw-login-bg-poster.jpg',
  fullBleed = true,
  softVignette = false,
}) => {
  return (
    <div
      className={`${fullBleed ? 'fixed' : 'absolute'} inset-0 z-0 overflow-hidden pointer-events-none select-none bg-[#04070f]`}
    >
      {/* ── Brand video, edge-to-edge within its container ── */}
      <video
        src={videoSrc}
        poster={posterSrc}
        autoPlay
        loop
        muted
        playsInline
        className="absolute inset-0 w-full h-full object-cover"
        style={{
          filter: 'brightness(0.72) saturate(1.15) contrast(1.05)',
          imageRendering: 'auto',
        }}
      />

      {/* ── Vignette: keeps overlaid copy readable over the video ── */}
      <div
        className="absolute inset-0"
        style={
          softVignette
            ? {
                background:
                  'linear-gradient(180deg, rgba(4,7,15,0.75) 0%, rgba(4,7,15,0.15) 28%, rgba(4,7,15,0.05) 60%, rgba(4,7,15,0.55) 100%), linear-gradient(90deg, rgba(4,7,15,0.35) 0%, transparent 22%)',
              }
            : {
                background:
                  'radial-gradient(circle at 42% 48%, transparent 22%, rgba(4,7,15,0.55) 65%, rgba(4,7,15,0.85) 100%), linear-gradient(180deg, rgba(4,7,15,0.65) 0%, rgba(4,7,15,0.2) 20%, rgba(4,7,15,0.2) 78%, rgba(4,7,15,0.88) 100%)',
              }
        }
      />
    </div>
  );
};
