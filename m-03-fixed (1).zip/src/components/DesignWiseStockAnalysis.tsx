import React, { useMemo, useState } from 'react';
import {
  Gem,
  Layers,
  Package,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  Search,
  Download,
  ChevronRight,
} from 'lucide-react';
import { RedistributionReport } from '../types';
import * as XLSX from 'xlsx';

interface DesignWiseStockAnalysisProps {
  report: RedistributionReport;
  onSelectWeight?: (weight: string) => void;
}

type DesignRow = {
  design: string;
  carat: string;
  itemKey: string;
  stock: number;
  sold: number;
  refill: number;
  moveIn: number;
  moveOut: number;
  turnover: number;
  velocity: string;
};

type DesignGroup = {
  design: string;
  stock: number;
  sold: number;
  refill: number;
  lines: number;
  rows: DesignRow[];
};

function splitItemKey(key: string): { carat: string; design: string } {
  const parts = String(key || '').split(' · ');
  if (parts.length >= 2) {
    return { carat: parts[0].trim(), design: parts.slice(1).join(' · ').trim() };
  }
  return { carat: key, design: '(Category / No Style)' };
}

/**
 * Design-wise Stock Analysis
 * Groups matrix rows by Oracle style code (NP7SD1, NP7SD10…) when present;
 * falls back to carat-only analysis for category uploads.
 */
export const DesignWiseStockAnalysis: React.FC<DesignWiseStockAnalysisProps> = ({
  report,
  onSelectWeight,
}) => {
  const [search, setSearch] = useState('');
  const [selectedDesign, setSelectedDesign] = useState<string>('ALL');
  const [sortBy, setSortBy] = useState<'sold' | 'stock' | 'refill' | 'turnover'>('sold');

  const { groups, hasDesign, flatRows } = useMemo(() => {
    const rows: DesignRow[] = report.weightSummaries.map((w) => {
      const { carat, design } = splitItemKey(w.weight);
      return {
        design,
        carat,
        itemKey: w.weight,
        stock: w.currentStock,
        sold: w.soldQty,
        refill: w.unmetShortage || 0,
        moveIn: w.moveInNeeded || 0,
        moveOut: w.moveOutNeeded || 0,
        turnover: w.turnoverRatio || 0,
        velocity: w.velocityCategory || '—',
      };
    });

    const hasDesign = rows.some((r) => r.design !== '(Category / No Style)');
    const map = new Map<string, DesignGroup>();

    rows.forEach((r) => {
      if (!map.has(r.design)) {
        map.set(r.design, {
          design: r.design,
          stock: 0,
          sold: 0,
          refill: 0,
          lines: 0,
          rows: [],
        });
      }
      const g = map.get(r.design)!;
      g.stock += r.stock;
      g.sold += r.sold;
      g.refill += r.refill;
      g.lines += 1;
      g.rows.push(r);
    });

    const groups = Array.from(map.values()).sort((a, b) => b.sold - a.sold);
    return { groups, hasDesign, flatRows: rows };
  }, [report.weightSummaries]);

  const filteredGroups = useMemo(() => {
    const q = search.trim().toLowerCase();
    return groups
      .filter((g) => selectedDesign === 'ALL' || g.design === selectedDesign)
      .map((g) => {
        let rows = g.rows;
        if (q) {
          rows = rows.filter(
            (r) =>
              r.design.toLowerCase().includes(q) ||
              r.carat.toLowerCase().includes(q) ||
              r.itemKey.toLowerCase().includes(q)
          );
        }
        rows = [...rows].sort((a, b) => {
          if (sortBy === 'sold') return b.sold - a.sold;
          if (sortBy === 'stock') return b.stock - a.stock;
          if (sortBy === 'refill') return b.refill - a.refill;
          return b.turnover - a.turnover;
        });
        return {
          ...g,
          rows,
          stock: rows.reduce((s, r) => s + r.stock, 0),
          sold: rows.reduce((s, r) => s + r.sold, 0),
          refill: rows.reduce((s, r) => s + r.refill, 0),
          lines: rows.length,
        };
      })
      .filter((g) => g.lines > 0);
  }, [groups, search, selectedDesign, sortBy]);

  const totals = useMemo(() => {
    return filteredGroups.reduce(
      (acc, g) => ({
        stock: acc.stock + g.stock,
        sold: acc.sold + g.sold,
        refill: acc.refill + g.refill,
        designs: acc.designs + 1,
        lines: acc.lines + g.lines,
      }),
      { stock: 0, sold: 0, refill: 0, designs: 0, lines: 0 }
    );
  }, [filteredGroups]);

  const handleExport = () => {
    const aoa: (string | number)[][] = [
      ['Design / Style', 'Carat', 'Item Key', 'Stock', 'Sold', 'Refill Demand', 'Move IN', 'Move OUT', 'Turnover', 'Velocity'],
    ];
    filteredGroups.forEach((g) => {
      g.rows.forEach((r) => {
        aoa.push([
          r.design,
          r.carat,
          r.itemKey,
          r.stock,
          r.sold,
          r.refill,
          r.moveIn,
          r.moveOut,
          Number(r.turnover.toFixed(2)),
          r.velocity,
        ]);
      });
    });
    const ws = XLSX.utils.aoa_to_sheet(aoa);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Design_Stock_Analysis');
    XLSX.writeFile(wb, `Design_Wise_Stock_Analysis_${Date.now()}.xlsx`);
  };

  return (
    <div className="space-y-3">
      {/* Header */}
      <div className="bg-white border border-[#d0d7de] px-3 py-2.5 flex flex-wrap items-center justify-between gap-2">
        <div>
          <h2 className="text-sm font-bold text-[#0f2744] flex items-center gap-2">
            <Layers className="w-4 h-4 text-[#0854a0]" />
            Design-wise Stock Analysis
          </h2>
          <p className="text-[11px] text-[#6a6d70] mt-0.5">
            {hasDesign
              ? 'Style sheets detected — analysis grouped by design code (NP7SD1, NP7SD10…)'
              : 'Category-level data — upload Oracle style sheets for design breakdown'}
          </p>
        </div>
        <button
          type="button"
          onClick={handleExport}
          className="inline-flex items-center gap-1.5 h-8 px-3 text-[12px] font-semibold bg-[#0854a0] text-white border border-[#0854a0] hover:bg-[#0a6ed1]"
        >
          <Download className="w-3.5 h-3.5" />
          Export Excel
        </button>
      </div>

      {/* KPI strip */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
        {[
          { label: 'Designs', value: totals.designs, icon: Layers, color: 'text-[#0854a0]' },
          { label: 'Carat lines', value: totals.lines, icon: Gem, color: 'text-amber-700' },
          { label: 'Total Stock', value: totals.stock, icon: Package, color: 'text-emerald-700' },
          { label: 'Total Sold', value: totals.sold, icon: TrendingUp, color: 'text-blue-700' },
          { label: 'Refill Need', value: totals.refill, icon: AlertTriangle, color: 'text-rose-700' },
        ].map((k) => (
          <div key={k.label} className="bg-white border border-[#d0d7de] px-3 py-2">
            <div className="text-[10px] font-semibold text-[#6a6d70] uppercase tracking-wide flex items-center gap-1">
              <k.icon className={`w-3 h-3 ${k.color}`} />
              {k.label}
            </div>
            <div className="text-lg font-bold text-[#1e293b] font-mono tabular-nums">
              {k.value.toLocaleString()}
            </div>
          </div>
        ))}
      </div>

      {/* Toolbar */}
      <div className="bg-[#edf0f4] border border-[#d9d9d9] px-3 py-2 flex flex-wrap items-end gap-2">
        <div className="min-w-[140px]">
          <label className="block text-[10px] text-[#6a6d70] mb-0.5">Design / Style</label>
          <select
            value={selectedDesign}
            onChange={(e) => setSelectedDesign(e.target.value)}
            className="h-8 border border-[#89919a] bg-white px-2 text-[12px] min-w-[140px]"
          >
            <option value="ALL">All designs</option>
            {groups.map((g) => (
              <option key={g.design} value={g.design}>
                {g.design} ({g.lines})
              </option>
            ))}
          </select>
        </div>
        <div className="min-w-[100px]">
          <label className="block text-[10px] text-[#6a6d70] mb-0.5">Sort by</label>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
            className="h-8 border border-[#89919a] bg-white px-2 text-[12px]"
          >
            <option value="sold">Sold</option>
            <option value="stock">Stock</option>
            <option value="refill">Refill</option>
            <option value="turnover">Turnover</option>
          </select>
        </div>
        <div className="flex-1 min-w-[160px]">
          <label className="block text-[10px] text-[#6a6d70] mb-0.5">Search</label>
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-2 top-1/2 -translate-y-1/2 text-[#89919a]" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="NP7SD1, 0.05…"
              className="w-full h-8 border border-[#89919a] bg-white pl-7 pr-2 text-[12px]"
            />
          </div>
        </div>
      </div>

      {/* Design summary cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
        {filteredGroups.map((g) => {
          const sellThrough = g.stock + g.sold > 0 ? (g.sold / (g.stock + g.sold)) * 100 : 0;
          return (
            <button
              key={g.design}
              type="button"
              onClick={() => setSelectedDesign(selectedDesign === g.design ? 'ALL' : g.design)}
              className={`text-left bg-white border px-3 py-2.5 hover:border-[#0854a0] transition-colors ${
                selectedDesign === g.design ? 'border-[#0854a0] ring-1 ring-[#0854a0]/30' : 'border-[#d0d7de]'
              }`}
            >
              <div className="flex items-center justify-between gap-2">
                <span className="text-[13px] font-bold text-[#0f2744] font-mono truncate">{g.design}</span>
                <ChevronRight className="w-3.5 h-3.5 text-[#89919a] shrink-0" />
              </div>
              <div className="mt-1.5 grid grid-cols-3 gap-1 text-[11px]">
                <div>
                  <div className="text-[#6a6d70]">Stock</div>
                  <div className="font-bold font-mono">{g.stock.toLocaleString()}</div>
                </div>
                <div>
                  <div className="text-[#6a6d70]">Sold</div>
                  <div className="font-bold font-mono text-blue-700">{g.sold.toLocaleString()}</div>
                </div>
                <div>
                  <div className="text-[#6a6d70]">Refill</div>
                  <div className={`font-bold font-mono ${g.refill > 0 ? 'text-rose-600' : 'text-emerald-700'}`}>
                    {g.refill.toLocaleString()}
                  </div>
                </div>
              </div>
              <div className="mt-1.5 h-1.5 bg-[#e8e8e8] overflow-hidden">
                <div
                  className="h-full bg-[#0854a0]"
                  style={{ width: `${Math.min(100, sellThrough)}%` }}
                />
              </div>
              <div className="text-[10px] text-[#6a6d70] mt-0.5">
                {g.lines} carat lines · sell-through {sellThrough.toFixed(0)}%
              </div>
            </button>
          );
        })}
      </div>

      {/* Detail grid */}
      <div className="bg-white border border-[#d0d7de] overflow-hidden">
        <div className="px-3 py-1.5 bg-[#f6f8fa] border-b border-[#d0d7de] text-[11px] font-semibold text-[#32363a]">
          Carat × Design detail
          {selectedDesign !== 'ALL' ? ` · ${selectedDesign}` : ''}
        </div>
        <div className="overflow-x-auto max-h-[480px]">
          <table className="w-full text-[11px] border-collapse">
            <thead className="sticky top-0 bg-[#f6f8fa] z-10">
              <tr>
                {['Design', 'Carat', 'Stock', 'Sold', 'Refill', 'Move IN', 'Move OUT', 'Turnover', 'Velocity'].map(
                  (h) => (
                    <th
                      key={h}
                      className="border border-[#d0d7de] px-2 py-1.5 text-left font-semibold text-[#32363a] whitespace-nowrap"
                    >
                      {h}
                    </th>
                  )
                )}
              </tr>
            </thead>
            <tbody>
              {filteredGroups.flatMap((g) =>
                g.rows.map((r) => (
                  <tr
                    key={r.itemKey}
                    className="hover:bg-[#eef5ff] cursor-pointer"
                    onClick={() => onSelectWeight?.(r.itemKey)}
                  >
                    <td className="border border-[#e6e8eb] px-2 py-1 font-mono font-semibold text-[#0854a0]">
                      {r.design}
                    </td>
                    <td className="border border-[#e6e8eb] px-2 py-1 font-mono">{r.carat}</td>
                    <td className="border border-[#e6e8eb] px-2 py-1 text-right font-mono">{r.stock}</td>
                    <td className="border border-[#e6e8eb] px-2 py-1 text-right font-mono text-blue-700">{r.sold}</td>
                    <td
                      className={`border border-[#e6e8eb] px-2 py-1 text-right font-mono font-bold ${
                        r.refill > 0 ? 'text-rose-600' : 'text-slate-400'
                      }`}
                    >
                      {r.refill || '—'}
                    </td>
                    <td className="border border-[#e6e8eb] px-2 py-1 text-right font-mono text-emerald-700">
                      {r.moveIn || '—'}
                    </td>
                    <td className="border border-[#e6e8eb] px-2 py-1 text-right font-mono text-amber-700">
                      {r.moveOut || '—'}
                    </td>
                    <td className="border border-[#e6e8eb] px-2 py-1 text-right font-mono">
                      {r.turnover.toFixed(2)}
                    </td>
                    <td className="border border-[#e6e8eb] px-2 py-1">
                      <span
                        className={`inline-block px-1.5 py-0.5 text-[10px] font-semibold ${
                          r.velocity === 'Best-Seller'
                            ? 'bg-emerald-50 text-emerald-800'
                            : r.velocity === 'Zero-Sales Stock'
                              ? 'bg-rose-50 text-rose-800'
                              : 'bg-slate-50 text-slate-600'
                        }`}
                      >
                        {r.velocity}
                      </span>
                    </td>
                  </tr>
                ))
              )}
              {filteredGroups.length === 0 && (
                <tr>
                  <td colSpan={9} className="px-3 py-8 text-center text-[#6a6d70]">
                    No design rows — upload stock/sold style sheets (NP7SD1, NP7SD10…) or clear filters.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
